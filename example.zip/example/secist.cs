using System;
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
         System.Diagnostics.Process.Start("calc.exe");  
        }
    }
}